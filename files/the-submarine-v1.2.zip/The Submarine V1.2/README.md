## The Submarine

A 2D point and click game made using Unity. Pick up items, combine items, and solve tricky puzzles in order to escape from the submarine deep under the sea.

## How To Play

Begin the game by opening the **The Submarine.exe** file
For best results:
1. set Graphics quality as **Ultra**
2. play with SOUND (I spent so long on music and sound effects, please listen to them!!!)

Just a regular room escape game. Explore the submarine by clicking various parts on the screen.

## Reporting Bugs and Issues

Please contact me if you find any bugs or have recommendations:
* Email: sofia.fong5@hotmail.com

## Copyright and License

Feel free to distribute with CREDITS!
Please share with your friends if you enjoyed playing my game!