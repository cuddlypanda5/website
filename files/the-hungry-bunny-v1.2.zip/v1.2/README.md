## The Hungry Bunny

A simple and fun Single Screen 2D game made using Unity and C#. The player is a hungry bunny that goes around to eat all the carrots on the farm. Art done using a mouse on paint so don't expect too much...

## How To Play

Begin the game by opening the **2D.exe** file
For best results set:
1. Screen resolution as **1024 x 768**
2. Graphics quality as **Ultra**

Move around using the arrow keys and avoid the bouncing red monsters that appear!

## Reporting Bugs and Issues

Please contact me if you find any bugs or have recommendations:
* Email: sofia.fong5@hotmail.com

## Copyright and License

NONE! Feel free to distribute? (Not sure why you would want to though)